---
title: Guide to yatay geçiş as a ytb student
description: A field guide to horizontal transfer for international scholarship students in türkiye.
order: 1
updated: 2026-07-21
wip: true
---

# Guide to yatay geçiş as a ytb student

not satisfied with where you are? 😭 well so was i. and i have tried to compile all the necessary steps that u might need when planning on transferring unis as a ytb student. this guide isn't complete yet as i am also attempting my transfer while im writing so i'll probably update it as i go.

one thing to note, the chances of the transfer actually pulling off is very low. i dont say this to discourage ppl or anything but the reality of the fact is that unis dont want to do bureaucratic work with a scholarship student who wont pay them anything in the middle of an already established class. as u go through this process, please try to temper your expectations and hopes and try to appreciate the place u are, as im pretty sure it has its beauties as well. 

also, throughout the guide, i will have to use my own experience as an example so whenever u get into the process, keep in mind it might not be exactly the same for u (for example, im pretty sure the medicine students are weird and have weird transfer mechanics, but i didnt research that soooo . . . best of luck). annyyyways, into it.

## what is yatay geçiş?

tl;dr: what ur interested in is kurumlar arası yatay geçiş, use that when researching

literally stands for horizontal transfer. in türkiye, there are two kinds of transfer: yatay and dikey, aka horizontal and vertical. vertical transfer is when ur trying to change ur field entirely. u see, the majority of uni assigning and field selection in türkiye is tied with their high school exit exam score aka ÖSYS. and if ur reading this, u prolly dont have this ÖSYS cuz ur an international student and these exams are only for local turks.

what we are specifically interested in is the yatay geçiş where u transfer unis but stay in the same field (in my case for example computer engineering or bilgisayar mühendisliği). again inside yatay geçiş, there are multiple kinds. i will list and briefly describe each and point out which applies to us (us being international YTB scholarship students):
- kurum içi yatay geçiş: only applicable for transfer of _different fields_ inside the _same_ uni
- kurumlar arası yatay geçiş (the one we're interested in): transfer between two different unis under the _same field_. this is again split into two. these divisions arent very significant during the process but it will be important when checking out the quotas (kontenjan) of the uni (more on quota/kontenjan later). here are the types:
	- yurt içi: transfer from a uni thats in türkiye (what we're interested in)
	- yurt dışı: transfer from a uni thats outside türkiye

so now we know what we are looking for: kurumlar arası [yurt içi] yatay geçiş. when u wanna look sth up, use these keywords always.

one other thing that needs to be cleared up (as it will be important with ytb later) is the difference between a transfer student and a fresh student. one thing u need to be wary about is that unis will always want students (cuz, money, duh.) and especially considering ur a foreignier? done deal. so they will always do their best to get u to sign up to their uni. and one thing that is tricky is what u are registering to that uni as. when ur applying to their uni as a transfer student, u are entering the 2nd or 3rd year class of ur field and this is very important for ytb. unis always offer u the option, "_just in case_ the transfer doesnt work, you can always apply as a first year student and we would transfer the credits for your course!" on the face of it, it seems innocent; ur credits arent wasted after all. but this is a deal breaker for ytb cuz now, you have legitimate reason to extend ur stay at türkiye and consequently take even more of their money.

so after all that preamble, what im trying to say is, make sure ur applying or get accepted as a 2nd or 3rd year student specifically, and not as a first year student who had their credits tranferred.

## when should u start worrying about this?

tl;dr: start worrying around mid to end of June. but preferably worry all years cuz ur gpa matters.

before i go on, i need to make sure that u arent unduly worried. that is, if its actually even the time to worry about this. most american unis usually have application windows, be it transfer or fresh, during sept-dec or even up to april. That is NOT the case here. unis in türkiye ALWAYS open their transfer applications _after_ the academic year is complete (usually around the end of june, all of july and early august).

so when should u start running around like a headless chicken? since the start of the year ofc. jk jk. but seriously, as a uni student, ur major stand out point is ur results, and they even specify that u _must_ pass all ur courses to be considered for transfer (more on that later). so yeah, ur results do matter a lot. so start worrying early.

but the real work on the transfer will start after the end of the normal academic year, so around end of June and early July and the actual real work will be during the months of July and august.

## what do i actually need?

tl;dr: each uni have their own wants and needs, find their yatay geçiş yönergesi to make sure exactly what they need. some common requirements are listed below.

as with any comparison, the easiest way to determine who is the better option is by . . . numbers. exactly. we need numbers. scores, grades, competitions, 1st places, good marks, etc etc. which numbers? thats where it gets a bit iffy. in my experience applying, some unis DEMAND ösys scores and some are more lenient for international students like us. which brings me to my most important point of this part of the article: how to get real info.

the process for each uni is always different, what they accept, what they want, how they evaluate, each is different in their own ways. however, one sweet thing about the Turkish government is that they force these unis to have a dedicated yönergesi (aka directive) about their horizontal/vertical transfer rules. so if u are interested in a uni, it will indubitably have a directive. the issue comes in finding it. some unis hide theirs so deep in their website, it takes literal hours to find it. however, u mustn't give up cuz this directive is ur only verified source of info about the transfer process for that uni. so whatever u do, make sure u read (read "make chatgpt read") the directive.

but there are some common requirements:
1. ösys results
sooo, i think i ranted about this exam a bit already but i say it again, they will more likely than not as you about this bloddy exam. as international students, we CANT take this exam. its literally impossible. so stop ripping ur hair out about this as soon as possible.

"well u told me the problem, whats the solution?" the purpose of the ösys is for placement/uni entrance in türkiye. so a sufficient replacement for the ösys would be the exam that got u the scholarship in the first place. i'll list some of the common ones:
- SAT: broadly well received. u can usually use this as the "results" replacement for ösys
- ACT: its stands for American college test sooo yeah not very broadly accepted but better than nothing.
- ur national exam (if u have it): the national high school exit exam u took in ur own country. usually a good choice as it is a _national exam_. however most countries aren't recognized by most unis here (and no wonder, there are over 180 countries, u cant expect each uni to keep track of each of them)
- ur high school transcript: not a bad choice as well

these are a few example documents u can upload in place of the ösys. however, i strongly recommend u double check with the uni first before submitting anything.

we have done a bit to solve the problem but it still doesn't solve the greater problem the uni had: how can they quantitatively compare u to the other turk students when their exam metrics and urs differ? so i have found that the _common_ answer to this is by using the base entrance score for ur field in ur entry year. ". . . whaaaaat?" i hear you say? well, the ösys is the entrance exam right? well every year, they document the smallest result that was placed into each field and they store this data as "[ur field]'in taban puanı". considering that u _dont_ have the ösys exam, the uni by default takes the base score for ur field when calculating ur merit. what does this have to do with u? well some unis require u to upload the official base score for ur field for the year u entered uni as they dont want to go through the trouble of finding it themself. where can u find it? at yokatlas.yok.gov.tr (side note, i will list all resources at the bottom so u can find all of them there). so as i said, this is the solution taken by only _some_ unis so its always better to confirm from their directives or from the uni themselves either by calling or emailing them.

2. ösys placement document (not really confirmed whether my info here is accurate or not so take with a pinch of salt)
"ugh, again with the ösys" fret not, this one is just an extension of the previous one. the university placement document for us (ytb students) would be our acceptance letter and our bursluluk belgesi as it contains the place we were assigned. i have yet to find a better alternative for this but if u feel like u found a better document to replace this, feel free to use that one.

3. transcript
pretty obvious requirement. something to keep in mind here, the unis require the transcript to be verified and the only two ways they accept it is first, and easiest in my opinion, is to take it directly from ur e-devlet. if it hasn't updated to include all ur scores so far talk to ur uni's student affairs office (öğrenci işleri). second is to get a signed and stamped printout of ur transcript from ur uni. pick whichever but i suggest the edevlet version. make sure that the date u took the transcript is not later than two weeks before ur transfer application.

4. öğrenci belgesi (student document)
same as the transcript, either take the edevlet one or a signed and stamped printout version from ur uni.

5. discipline document (disiplin belgesi)
_usually_ u can get this document directly from ur student portal of ur uni. however (and this was the case for me) there might be some issues that prevent u from doing so. so in this case, go to ur student affairs office and specifically as for a disiplin belgesi for yatay geçiş application. for me, they basically gave me an öğrenci belgesi with a little note at the bottom that says "this student hasn't been naughty and hasn't paid any punishment fees so far."

6. kimlik
scan and upload

7. passport
scan and upload

8. (if ur transferring to an English course) English proficiency document
i will dive deeper into this later but if u are applying to an English program, u must prove ur English proficiency. again, which exams they accept differs depending on the uni, however, generally, u must submit an exam result that is above what score they set that u have taken within the past two years. a few exams i have seen consistently be accepted are: TOEFL, PTE Academic. (surprisingly, most unis dont accept IELTS, duo and SAT as substitutions for an English proficiency). most, if not all, unis have their own exams that u could take to show u have the English necessary.

PS. this applies if u are transferring to a Turkish program as well. u must show ur proficiency in the Turkish language but assuming u are a ytb scholar, then u already took a year of TÖMER with ur original uni so u should be good.

---

and i think thats most of the common documents requested. some might ask for more and some might as for less, its always best to double check for each uni.

##
